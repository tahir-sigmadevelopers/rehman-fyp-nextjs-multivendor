# 01-install-ai-tools-and-vscode-extensions

1. install codeium extensions
2. create codeium account
3. use codeium in vscode
4. install vscode extensions
   1. eslint
   2. prettier
   3. vscode-icons
   4. tailwindcss
   5. es7+ react snippets
   6. pretty typescript errors
