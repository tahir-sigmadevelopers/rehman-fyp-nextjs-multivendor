'use client'

// This is a placeholder file to satisfy the build process
// The actual notifications system has been removed
// Added this comment to force a rebuild

export default function NotificationsDropdown() {
  return null
} 